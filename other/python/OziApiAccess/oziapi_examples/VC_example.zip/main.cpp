
/////////////////////////////////////////
// Program to test the OziExplorer API //
/////////////////////////////////////////

#include <windows.h>   
#include "main.h"   
#include "resource.h"
#include "oziapi.h"



HINSTANCE g_hInst;		// the current instance		
HWND hwndMain;
HWND hwndOziTestDlg;


void ShowMessage(LPCTSTR m)
{
MessageBox(hwndMain,m,TEXT("OziExplorer"),MB_OK | MB_ICONEXCLAMATION);
}


 
//
//  FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)
//
//  PURPOSE: Entry point for the application.
//
int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
    LPSTR lpCmdLine, int nCmdShow )
{

    MSG msg;

    if (!InitApplication(hInstance))
            return (FALSE);              

    // Create the main window.
    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);




//*************************************************************************//
//Load the OziAPI DLL
//there are many places in program startup where this could be loaded
if (LoadOziApiDll()!=0) {ShowMessage("OziAPI.dll could not be loaded");};
//*************************************************************************//



    // Acquire and dispatch messages until a WM_QUIT message is received.
    while (GetMessage(&msg,NULL,0,0))
        {
            TranslateMessage(&msg);    // Translates virtual key codes.
            DispatchMessage(&msg);     // Dispatches message to window.
        }


    return (msg.wParam);           // Returns the value from PostQuitMessage.




}


//
//  FUNCTION: InitApplication(HANDLE)
//
//  PURPOSE: Initializes window data and registers window class 
//
BOOL InitApplication(HANDLE hInstance)       
{
    WNDCLASS  wc;

    // Register the window class for my window.                                                           */
    wc.style = 0;                       // Class style.
    wc.lpfnWndProc = (WNDPROC)MainWndProc; // Window procedure for this class.
    wc.cbClsExtra = 0;                  // No per-class extra data.
    wc.cbWndExtra = 0;                  // No per-window extra data.
    wc.hInstance = hInstance;           // Application that owns the class.
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "IDR_MENU1";   // Name of menu resource in .RC file. 
    wc.lpszClassName = "OziWClass"; // Name used in call to CreateWindow.

    return (RegisterClass(&wc));
}


//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window 
//
BOOL InitInstance( HANDLE hInstance, int nCmdShow)           
{
    HWND            hWnd;              

	// Save off the handle to the current instance.
    g_hInst = hInstance;

    // Create a main window for this application instance. 
    hWnd = CreateWindow(
        "OziWClass",
        "Ozi API Test",
        WS_OVERLAPPEDWINDOW,            // Window style.
        400,                  // Default horizontal position.
        100,                  // Default vertical position.
        550,                  // Default width.
        360,                  // Default height.
        NULL,                           // Overlapped windows have no parent.
        NULL,                           // Use the window class menu.
        g_hInst,                        // This instance owns this window.
        NULL                            // Pointer not needed.
    );

    // If window could not be created, return "failure".
    if (!hWnd)
        return (FALSE);


    // Make the window visible; update its client area; and return "success".
    ShowWindow(hWnd, nCmdShow);  
    UpdateWindow(hWnd);          
    return (TRUE);               

}

//
//  FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
LONG APIENTRY MainWndProc( HWND hWnd, UINT message, UINT wParam, LONG lParam)
{

    switch (message) {

        case WM_CREATE:
             hwndMain = hWnd;
            return 0;
 

        case WM_COMMAND:           // message: command from application menu 
            switch( LOWORD( wParam ))
            {
                case IDM_TESTOZIAPI:
                     DialogBox(g_hInst,MAKEINTRESOURCE(IDD_OZITESTDIALOG),hWnd,(DLGPROC)oziAPITest);
                     break;

                case IDM_EXIT:
                     PostQuitMessage(0);
                     break;

                default:
                    return (DefWindowProc(hWnd, message, wParam, lParam));

            }
            break;


        case WM_DESTROY:                  // message: window being destroyed
            PostQuitMessage(0);
            break;


        default:
            return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return (0);
}






//TMapSingleClickCallback = procedure(var oType:pchar; x,y:integer;lat,lon:double;var zone:pchar;e,n:double);stdcall;
//TMapDblClickCallback = procedure(var oType:pchar; x,y:integer;lat,lon:double;var zone:pchar;e,n:double);stdcall;
//TObjectClickCallback = procedure(var oType:pchar; lat,lon:double;var zone:pchar;e,n:double);stdcall;

/////////////////////////////////////////////////////////
// these are the call back functions for the OziApi.dll
/////////////////////////////////////////////////////////
void MapSingleClickCallback(LPSTR *oType,int x, int y, double Lat, double Lon,
                            LPSTR *UTMZone, double easting, double northing)
{
//******************************//
// do all the processing here   //
//******************************//

// The type will be put in the edit box
//this is not necessary in a real application
HWND hCtrlWnd;
hCtrlWnd = GetDlgItem (hwndOziTestDlg, IDC_EDIT1);
SendMessage (hCtrlWnd, WM_SETTEXT, 0, (LPARAM)*oType);
}

void MapDblClickCallback(LPSTR *oType,int x, int y, double Lat, double Lon,
                            LPSTR *UTMZone, double easting, double northing)
{
//******************************//
// do all the processing here   //
//******************************//

// The type will be put in the edit box
//this is not necessary in a real application
HWND hCtrlWnd;
hCtrlWnd = GetDlgItem (hwndOziTestDlg, IDC_EDIT1);
SendMessage (hCtrlWnd, WM_SETTEXT, 0, (LPARAM)*oType);
}

void ObjectClickCallback(LPSTR *oType, double Lat, double Lon,
                            LPSTR *UTMZone, double easting, double northing, LPSTR *sName)
{
//******************************//
// do all the processing here   //
//******************************//


// The type will be put in the edit box
//this is not necessary in a real application
HWND hCtrlWnd;
hCtrlWnd = GetDlgItem (hwndOziTestDlg, IDC_EDIT1);
SendMessage (hCtrlWnd, WM_SETTEXT, 0, (LPARAM)*oType);
}



/////////////////////////////////////////////////////////
// end of callback functions ////////////////////////////
/////////////////////////////////////////////////////////





//////////////////////////////////////
// All the work is done here        //
// but this is only an example form //
//////////////////////////////////////

BOOL APIENTRY oziAPITest( HWND hDlg, UINT message, UINT wParam, LONG lParam)
{
  LPSTR WpName;
  LPSTR WpDesc;
  LPSTR MfName;
  LPSTR MfDesc;
  LPSTR MfPictureName;
  LPSTR MfSymbolName;
  LPSTR MapName;
  LPSTR FileName;

  double Lat,Lon;

  int return1;

  LPSTR b;
  int DataLength;
  HWND hCtrlWnd;

    switch (message)
    {
        case WM_INITDIALOG:

            hwndOziTestDlg=hDlg;

            return (TRUE);


        case WM_COMMAND:

            switch( LOWORD( wParam ))
            {
                case IDCANCEL:

                     EndDialog(hDlg, TRUE);
                     return TRUE;
                     break;

                case IDC_GETOZIPATH:

                     //get the Ozi exe path from OziExplorer
                     return1 = oziGetExePath(&b,&DataLength);

                     //put it in a edit box
                     hCtrlWnd = GetDlgItem (hDlg, IDC_EDIT1);
                     SendMessage (hCtrlWnd, WM_SETTEXT, 0, (LPARAM)b);

                     return TRUE;
                     break;

                case IDC_CENTERMAP:
                     Lat=-26.645;
                     Lon=152.616;
                     oziCenterMapAtPositionWithMark(Lat,Lon);
                     return TRUE;
                     break;

                case IDC_CLEARWPS:
                     oziClearWPs();
                     return TRUE;
                     break;

                case IDC_CREATEWP:
                     //this creates a waypoint on a OziExplorer map at the specified
                     //position using the specified parameters

                     WpName = (LPSTR)malloc(20);
                     strcpy(WpName,"MY_WP");

                     WpDesc = (LPSTR)malloc(50);
                     strcpy(WpDesc,"WP Description");

                     Lat=-26.629;
                     Lon=152.315;

                     return1=oziCreateWP(&WpName  //name
                                         ,-1      //use the default symbol
                                         ,Lat,Lon //the lat lon
                                         ,-777    //the altitude
                                         ,-1      //let OziExplorer assign the date
                                         ,-1      //use the default Map Display Format
                                         ,-1      //use the default Pointer Direction
                                         ,-1      //use the default Garmin Display Format
                                         ,255     //set the fore color to red
                                         ,-1      //use the default back color
                                         ,0       //the proximity distance
                                         ,&WpDesc //the Description
                                         ,12      //set the font size to 12
                                         ,1       //set the font style to bold
                                         ,-1      //use the default symbol size
                                         );

                     free(WpName);
                     free(WpDesc);

                     return TRUE;
                     break;


                case IDC_CLEARMFS:
                     oziClearMFs();
                     return TRUE;
                     break;

                case IDC_CREATEMF:
                     //this creates a map feature on a OziExplorer map at the specified
                     //position using the specified parameters

                     MfName = (LPSTR)malloc(20);
                     strcpy(MfName,"MY_MF");

                     MfDesc = (LPSTR)malloc(50);
                     strcpy(MfDesc,"MF Description");

                     MfPictureName = (LPSTR)malloc(50);
                     strcpy(MfPictureName,"");

                     MfSymbolName = (LPSTR)malloc(50);
                     strcpy(MfSymbolName,"");

                     WpName = (LPSTR)malloc(20);
                     strcpy(WpName,"MY_WP");

                     Lat=-26.629;
                     Lon=152.415;

                     return1=oziCreateMF(&MfName  //name
                                         ,Lat,Lon //the lat lon
                                         ,&MfDesc
                                         ,&MfPictureName
                                         ,&MfSymbolName
                                         ,1      //create a wp
                                         ,&WpName
                                         );

                     free(MfName);
                     free(MfDesc);
                     free(MfPictureName);
                     free(MfSymbolName);
                     free(WpName);

                     return TRUE;
                     break;


                case IDC_MAPSINGLECLICK:
                     //this turns on the signle map click
                     //a click on an OziExplorer map will send the click position
                     //using the callback procedure provided
                     return1 = oziMapSingleClickON((int *)&MapSingleClickCallback);
                     return TRUE;
                     break;

                case IDC_MAPDOUBLECLICK:
                     //this turns on the double map click
                     //double clicks on an OziExplorer map will send the click position
                     //using the callback procedure provided
                     return1 = oziMapDblClickON((int *)&MapDblClickCallback);
                     return TRUE;
                     break;

                case IDC_OBJECTCLICK:
                     //this turns on the object click (waypoints, map features and so on)
                     //a click on an Object will send the click information
                     //using the callback procedure provided
                     return1 = oziObjectClickON((int *)&ObjectClickCallback);
                     return TRUE;
                     break;

                case IDC_LOADMAP:
                     //Loads a Map File
                     MapName = (LPSTR)malloc(50);
                     strcpy(MapName,"c:\\oziexplorer\\maps\\demo1.map");
                     return1 = oziLoadMap(&MapName);
                     free(MapName);
                     return TRUE;
                     break;

                case IDC_SAVEMAP:
                     //Saves a Map File
                     //if no map name is specified the map is saved
                     //using its current name
                     //if a name is specified the map is saved using the
                     //specified name
                     MapName = (LPSTR)malloc(50);
                     strcpy(MapName,"");
                     return1 = oziSaveMap(&MapName);
                     free(MapName);
                     return TRUE;
                     break;

                case IDC_LOADWPFILE:
                     //Loads a Waypoint File
                     FileName = (LPSTR)malloc(50);
                     strcpy(FileName,"c:\\oziexplorer\\data\\demo1.wpt");
                     return1 = oziLoadWPfile(&FileName);
                     free(FileName);
                     return TRUE;
                     break;

                case IDC_LOADTRKFILE:
                     //Loads a Track File into track 2
                     FileName = (LPSTR)malloc(50);
                     strcpy(FileName,"c:\\oziexplorer\\data\\demo1.plt");
                     return1 = oziLoadTRKfile(2,&FileName);
                     free(FileName);
                     return TRUE;
                     break;

                case IDC_CLEARTRACKS:
                     oziClearTRKs();
                     return TRUE;
                     break;

                case IDC_CLEARTRACK2:
                     oziClearTRK(2);
                     return TRUE;
                     break;

            }
    }
    return FALSE;

}

