//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_OZITESTDIALOG               102
#define IDC_EDIT1                       1000
#define IDC_BUTTON1                     1001
#define IDC_GETOZIPATH                  1001
#define IDC_BUTTON2                     1002
#define IDC_CENTERMAP                   1002
#define IDC_CLEARWPS                    1003
#define IDC_MAPSINGLECLICK              1004
#define IDC_CREATEWP                    1005
#define IDC_CREATEMF                    1006
#define IDC_CLEARMFS                    1007
#define IDC_OBJECTCLICK                 1008
#define IDC_MAPDOUBLECLICK              1009
#define IDC_LOADMAP                     1010
#define IDC_SAVEMAP                     1011
#define IDC_LOADWPFILE                  1012
#define IDC_LOADTRKFILE                 1013
#define IDC_CLEARTRACKS                 1014
#define IDC_CLEARTRACK2                 1015
#define ID_TEST_TESTOZIAPI              40001
#define IDM_TESTOZIAPI                  40001
#define IDM_EXIT                        40002
#define ID_TEST_REEE                    40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
