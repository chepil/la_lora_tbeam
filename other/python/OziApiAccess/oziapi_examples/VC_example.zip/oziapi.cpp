
///////////////////////////////////////////////////////////////////////
// contains the declarations for the OziExplorer API dll  (OziAPI.dll)
// call the function  LoadOziApiDll() from your own program
// returns  0 if successful
//         -1 if the OziAPI.dll was not found
//         -2 if a function inside the DLL could not be assigned
///////////////////////////////////////////////////////////////////////

#include "oziapi.h"

HINSTANCE oziApiDll;           // Handle to DLL


ToziGetExePath oziGetExePath;

ToziCenterMapAtPosition oziCenterMapAtPosition;
ToziCenterMapAtPositionWithMark oziCenterMapAtPositionWithMark;
ToziCloseProgram oziCloseProgram;
ToziFindOzi oziFindOzi;
ToziGetMapDatum oziGetMapDatum;

ToziConvertDatum oziConvertDatum;

ToziClearWPs oziClearWPs;
ToziClearEVs oziClearEVs;
ToziClearRTEs oziClearRTEs;
ToziClearTRKs oziClearTRKs;
ToziClearTRK oziClearTRK;
ToziClearPTs oziClearPTs;
ToziClearMFs oziClearMFs;
ToziClearMCs oziClearMCs;

ToziCreateWP oziCreateWP;
ToziCreateMF oziCreateMF;
ToziCreateMC oziCreateMC;

ToziMapSingleClickON oziMapSingleClickON;
ToziMapSingleClickOFF oziMapSingleClickOFF ;
ToziMapDblClickON oziMapDblClickON;
ToziMapDblClickOFF oziMapDblClickOFF;
ToziObjectClickON oziObjectClickON;
ToziObjectClickOFF oziObjectClickOFF;

ToziLoadMap oziLoadMap;
ToziSaveMap oziSaveMap;

ToziLoadWPfile oziLoadWPfile;
ToziLoadTRKfile oziLoadTRKfile;

ToziChangeTRKcolor oziChangeTRKcolor;


//these are for multi tracking
ToziMTStartMultiTrack oziMTStartMultiTrack;
ToziMTStopMultiTrack oziMTStopMultiTrack;
ToziMTSendPosition oziMTSendPosition;
ToziMTloadIDsON oziMTloadIDsON;
ToziMTloadIDsOFF oziMTloadIDsOFF;


////////////////////////////////////////////
// call this function to load the oziAPI.dll
// and set up the function calls
////////////////////////////////////////////

int LoadOziApiDll(void)
{


oziApiDll = LoadLibrary("oziapi.dll");
if (oziApiDll == NULL)  {return -1;}


oziGetExePath = (ToziGetExePath)GetProcAddress(oziApiDll,"oziGetExePath");
if (!oziGetExePath) { FreeLibrary(oziApiDll);return -2;}

oziCenterMapAtPosition = (ToziCenterMapAtPosition)GetProcAddress(oziApiDll,"oziCenterMapAtPosition");
if (!oziCenterMapAtPosition) { FreeLibrary(oziApiDll);return -2;}

oziCenterMapAtPositionWithMark = (ToziCenterMapAtPositionWithMark)GetProcAddress(oziApiDll,"oziCenterMapAtPositionWithMark");
if (!oziCenterMapAtPositionWithMark) { FreeLibrary(oziApiDll);return -2;}

oziCloseProgram = (ToziCloseProgram)GetProcAddress(oziApiDll,"oziCloseProgram");
if (!oziCloseProgram) { FreeLibrary(oziApiDll);return -2;}

oziFindOzi = (ToziFindOzi)GetProcAddress(oziApiDll,"oziFindOzi");
if (!oziFindOzi) { FreeLibrary(oziApiDll);return -2;}


oziGetMapDatum = (ToziGetMapDatum)GetProcAddress(oziApiDll,"oziGetMapDatum");
if (!oziGetMapDatum) { FreeLibrary(oziApiDll);return -2;}

oziConvertDatum = (ToziConvertDatum)GetProcAddress(oziApiDll,"oziConvertDatum");
if (!oziConvertDatum) { FreeLibrary(oziApiDll);return -2;}

oziClearWPs = (ToziClearWPs)GetProcAddress(oziApiDll,"oziClearWPs");
if (!oziClearWPs) { FreeLibrary(oziApiDll);return -2;}

oziClearEVs = (ToziClearEVs)GetProcAddress(oziApiDll,"oziClearEVs");
if (!oziClearEVs) { FreeLibrary(oziApiDll);return -2;}

oziClearRTEs = (ToziClearRTEs)GetProcAddress(oziApiDll,"oziClearRTEs");
if (!oziClearRTEs) { FreeLibrary(oziApiDll);return -2;}

oziClearTRKs = (ToziClearTRKs)GetProcAddress(oziApiDll,"oziClearTRKs");
if (!oziClearTRKs) { FreeLibrary(oziApiDll);return -2;}

oziClearTRK = (ToziClearTRK)GetProcAddress(oziApiDll,"oziClearTRK");
if (!oziClearTRK) { FreeLibrary(oziApiDll);return -2;}

oziClearPTs = (ToziClearPTs)GetProcAddress(oziApiDll,"oziClearPTs");
if (!oziClearPTs) { FreeLibrary(oziApiDll);return -2;}

oziClearMFs = (ToziClearMFs)GetProcAddress(oziApiDll,"oziClearMFs");
if (!oziClearMFs) { FreeLibrary(oziApiDll);return -2;}

oziClearMCs = (ToziClearMCs)GetProcAddress(oziApiDll,"oziClearMCs");
if (!oziClearMCs) { FreeLibrary(oziApiDll);return -2;}

oziCreateWP = (ToziCreateWP)GetProcAddress(oziApiDll,"oziCreateWP");
if (!oziCreateWP) { FreeLibrary(oziApiDll);return -2;}

oziCreateMF = (ToziCreateMF)GetProcAddress(oziApiDll,"oziCreateMF");
if (!oziCreateMF) { FreeLibrary(oziApiDll);return -2;}

oziCreateMC = (ToziCreateMC)GetProcAddress(oziApiDll,"oziCreateMC");
if (!oziCreateMC) { FreeLibrary(oziApiDll);return -2;}

oziMapSingleClickON = (ToziMapSingleClickON)GetProcAddress(oziApiDll,"oziMapSingleClickON");
if (!oziMapSingleClickON) { FreeLibrary(oziApiDll);return -2;}

oziMapSingleClickOFF = (ToziMapSingleClickOFF)GetProcAddress(oziApiDll,"oziMapSingleClickOFF");
if (!oziMapSingleClickOFF) { FreeLibrary(oziApiDll);return -2;}

oziMapDblClickON = (ToziMapDblClickON)GetProcAddress(oziApiDll,"oziMapDblClickON");
if (!oziMapDblClickON) { FreeLibrary(oziApiDll);return -2;}

oziMapDblClickOFF = (ToziMapDblClickOFF)GetProcAddress(oziApiDll,"oziMapDblClickOFF");
if (!oziMapDblClickOFF) { FreeLibrary(oziApiDll);return -2;}

oziObjectClickON = (ToziObjectClickON)GetProcAddress(oziApiDll,"oziObjectClickON");
if (!oziObjectClickON) { FreeLibrary(oziApiDll);return -2;}

oziObjectClickOFF = (ToziObjectClickOFF)GetProcAddress(oziApiDll,"oziObjectClickOFF");
if (!oziObjectClickOFF) { FreeLibrary(oziApiDll);return -2;}

oziLoadMap = (ToziLoadMap)GetProcAddress(oziApiDll,"oziLoadMap");
if (!oziLoadMap) { FreeLibrary(oziApiDll);return -2;}

oziSaveMap = (ToziSaveMap)GetProcAddress(oziApiDll,"oziSaveMap");
if (!oziSaveMap) { FreeLibrary(oziApiDll);return -2;}

oziLoadWPfile = (ToziLoadWPfile)GetProcAddress(oziApiDll,"oziLoadWPfile");
if (!oziLoadWPfile) { FreeLibrary(oziApiDll);return -2;}

oziLoadTRKfile = (ToziLoadTRKfile)GetProcAddress(oziApiDll,"oziLoadTRKfile");
if (!oziLoadTRKfile) { FreeLibrary(oziApiDll);return -2;}

oziChangeTRKcolor = (ToziChangeTRKcolor)GetProcAddress(oziApiDll,"oziChangeTRKcolor");
if (!oziChangeTRKcolor) { FreeLibrary(oziApiDll);return -2;}

oziMTStartMultiTrack = (ToziMTStartMultiTrack)GetProcAddress(oziApiDll,"oziMTStartMultiTrack");
if (!oziMTStartMultiTrack) { FreeLibrary(oziApiDll);return -2;}

oziMTStopMultiTrack = (ToziMTStopMultiTrack)GetProcAddress(oziApiDll,"oziMTStopMultiTrack");
if (!oziMTStopMultiTrack) { FreeLibrary(oziApiDll);return -2;}

oziMTSendPosition = (ToziMTSendPosition)GetProcAddress(oziApiDll,"oziMTSendPosition");
if (!oziMTSendPosition) { FreeLibrary(oziApiDll);return -2;}

oziMTloadIDsON = (ToziMTloadIDsON)GetProcAddress(oziApiDll,"oziMTloadIDsON");
if (!oziMTloadIDsON) { FreeLibrary(oziApiDll);return -2;}

oziMTloadIDsOFF = (ToziMTloadIDsOFF)GetProcAddress(oziApiDll,"oziMTloadIDsOFF");
if (!oziMTloadIDsOFF) { FreeLibrary(oziApiDll);return -2;}

return 0;

}

