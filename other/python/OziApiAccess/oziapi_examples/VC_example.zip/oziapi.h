///////////////////////////////////////////////////////////////////////
// contains the declarations for the OziExplorer API dll  (OziAPI.dll)
// oziapi.cpp is also required
///////////////////////////////////////////////////////////////////////

#ifndef _oziapi_h_
#define _oziapi_h_

#include "windows.h"

typedef int (CALLBACK* ToziGetExePath)(char **, int *);

typedef int (CALLBACK* ToziCenterMapAtPosition)(double, double);
typedef int (CALLBACK* ToziCenterMapAtPositionWithMark)(double, double);
typedef int (CALLBACK* ToziCloseProgram)(void);
typedef int (CALLBACK* ToziFindOzi)(void);
typedef int (CALLBACK* ToziGetMapDatum)(char **, int *);

typedef int (CALLBACK* ToziConvertDatum)(char **, char **, double *, double *);

typedef int (CALLBACK* ToziClearWPs)(void);
typedef int (CALLBACK* ToziClearEVs)(void);
typedef int (CALLBACK* ToziClearRTEs)(void);
typedef int (CALLBACK* ToziClearTRKs)(void);
typedef int (CALLBACK* ToziClearTRK)(int);
typedef int (CALLBACK* ToziClearPTs)(void);
typedef int (CALLBACK* ToziClearMFs)(void);
typedef int (CALLBACK* ToziClearMCs)(void);


typedef int (CALLBACK* ToziCreateWP)(char **, int ,double, double, double, double, int, int, int, int, int, int,
                                     char **, int, int, int);

typedef int (CALLBACK* ToziCreateMF)(char **, double, double, char **, char **, char **, int, char **);

typedef int (CALLBACK* ToziCreateMC)(char **, double, double, int, int, int, int , int, int);


typedef int (CALLBACK* ToziMapSingleClickON)(int *);
typedef int (CALLBACK* ToziMapSingleClickOFF)(void);
typedef int (CALLBACK* ToziMapDblClickON)(int *);
typedef int (CALLBACK* ToziMapDblClickOFF)(void);
typedef int (CALLBACK* ToziObjectClickON)(int *);
typedef int (CALLBACK* ToziObjectClickOFF)(void);

typedef int (CALLBACK* ToziLoadMap)(char **);
typedef int (CALLBACK* ToziSaveMap)(char **);
typedef int (CALLBACK* ToziLoadWPfile)(char **);
typedef int (CALLBACK* ToziLoadTRKfile)(int, char **);

typedef int (CALLBACK* ToziChangeTRKcolor)(int, int);

// multi tracking
typedef int (CALLBACK* ToziMTStartMultiTrack)(void);
typedef int (CALLBACK* ToziMTStopMultiTrack)(void);
typedef int (CALLBACK* ToziMTSendPosition)(char **);
typedef int (CALLBACK* ToziMTloadIDsON)(void);
typedef int (CALLBACK* ToziMTloadIDsOFF)(void);


//============================================================================
extern HINSTANCE oziApiDll;           // Handle to DLL

extern ToziGetExePath oziGetExePath;

extern ToziCenterMapAtPosition oziCenterMapAtPosition;
extern ToziCenterMapAtPositionWithMark oziCenterMapAtPositionWithMark;
extern ToziCloseProgram oziCloseProgram;
extern ToziFindOzi oziFindOzi;
extern ToziGetMapDatum oziGetMapDatum;

extern ToziConvertDatum oziConvertDatum;

extern ToziClearWPs oziClearWPs;
extern ToziClearEVs oziClearEVs;
extern ToziClearRTEs oziClearRTEs;
extern ToziClearTRKs oziClearTRKs;
extern ToziClearTRK oziClearTRK;
extern ToziClearPTs oziClearPTs;
extern ToziClearMFs oziClearMFs;
extern ToziClearMCs oziClearMCs;


extern ToziCreateWP oziCreateWP;
extern ToziCreateMF oziCreateMF;
extern ToziCreateMC oziCreateMC;

extern ToziMapSingleClickON oziMapSingleClickON;
extern ToziMapSingleClickOFF oziMapSingleClickOFF ;
extern ToziMapDblClickON oziMapDblClickON;
extern ToziMapDblClickOFF oziMapDblClickOFF;
extern ToziObjectClickON oziObjectClickON;
extern ToziObjectClickOFF oziObjectClickOFF;

extern ToziLoadMap oziLoadMap;
extern ToziSaveMap oziSaveMap;
extern ToziLoadWPfile oziLoadWPfile;
extern ToziLoadTRKfile oziLoadTRKfile;

extern ToziChangeTRKcolor oziChangeTRKcolor;


//these are for multi tracking
extern ToziMTStartMultiTrack oziMTStartMultiTrack;
extern ToziMTStopMultiTrack oziMTStopMultiTrack;
extern ToziMTSendPosition oziMTSendPosition;
extern ToziMTloadIDsON oziMTloadIDsON;
extern ToziMTloadIDsOFF oziMTloadIDsOFF;


int LoadOziApiDll(void);


#endif /* _oziapi_h_ */

